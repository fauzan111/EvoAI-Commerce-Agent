"""
Commerce agent tools for product search, order management, and policy enforcement.
"""
import json
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from pathlib import Path

# Load data files
DATA_DIR = Path(__file__).parent.parent / "data"

def load_products() -> List[Dict]:
    """Load products from JSON file."""
    with open(DATA_DIR / "products.json", "r") as f:
        return json.load(f)

def load_orders() -> List[Dict]:
    """Load orders from JSON file."""
    with open(DATA_DIR / "orders.json", "r") as f:
        return json.load(f)

def product_search(query: str, price_max: int = None, tags: List[str] = None) -> Dict[str, Any]:
    """
    Search products by query, price limit, and tags.
    Returns up to 2 products that match criteria.
    """
    products = load_products()
    results = []
    
    # Convert query to lowercase for matching
    query_lower = query.lower()
    
    for product in products:
        # Check price constraint
        if price_max and product["price"] > price_max:
            continue
            
        # Check tag matching
        if tags:
            product_tags = [tag.lower() for tag in product["tags"]]
            if not any(tag.lower() in product_tags for tag in tags):
                continue
        
        # Check query matching (title, tags, color)
        searchable_text = (
            product["title"].lower() + " " + 
            " ".join(product["tags"]).lower() + " " + 
            product["color"].lower()
        )
        
        if query_lower in searchable_text or any(word in searchable_text for word in query_lower.split()):
            results.append(product)
    
    # Return top 2 results, sorted by price (ascending)
    results.sort(key=lambda x: x["price"])
    return {"products": results[:2]}

def size_recommender(user_inputs: str) -> Dict[str, Any]:
    """
    Provide size recommendations based on user preferences.
    Simple heuristic-based recommendations.
    """
    user_lower = user_inputs.lower()
    
    # Simple heuristics
    if "between m/l" in user_lower or "m or l" in user_lower:
        recommendation = "M for a fitted look, L for a more relaxed fit"
        suggested_size = "M"
    elif "fitted" in user_lower or "tight" in user_lower:
        recommendation = "Go with the smaller size for a fitted look"
        suggested_size = "S"
    elif "loose" in user_lower or "relaxed" in user_lower:
        recommendation = "Go with the larger size for comfort"
        suggested_size = "L"
    else:
        recommendation = "M is typically our most popular size"
        suggested_size = "M"
    
    return {
        "recommendation": recommendation,
        "suggested_size": suggested_size
    }

def eta(zip_code: str) -> Dict[str, Any]:
    """
    Calculate estimated delivery time based on zip code.
    Simple rule-based system.
    """
    # Simple zip-based rules
    zip_str = str(zip_code)
    
    if zip_str.startswith(("1", "2", "3")):  # East Coast
        days = "2-3 days"
    elif zip_str.startswith(("4", "5", "6", "7")):  # Central
        days = "3-4 days"
    elif zip_str.startswith(("8", "9")):  # West Coast
        days = "4-5 days"
    else:
        days = "3-5 days"  # Default
    
    return {
        "zip_code": zip_code,
        "estimated_delivery": days,
        "shipping_method": "Standard"
    }

def order_lookup(order_id: str, email: str) -> Dict[str, Any]:
    """
    Look up order by ID and email for security.
    """
    orders = load_orders()
    
    for order in orders:
        if order["order_id"] == order_id and order["email"] == email:
            return {
                "found": True,
                "order": order
            }
    
    return {
        "found": False,
        "error": "Order not found or email doesn't match"
    }

def order_cancel(order_id: str, current_timestamp: str = None) -> Dict[str, Any]:
    """
    Cancel order if within 60-minute policy window.
    """
    orders = load_orders()
    
    # Use provided timestamp or current time
    if current_timestamp:
        now = datetime.fromisoformat(current_timestamp.replace('Z', '+00:00'))
    else:
        now = datetime.now(timezone.utc)
    
    for order in orders:
        if order["order_id"] == order_id:
            created_at = datetime.fromisoformat(order["created_at"].replace('Z', '+00:00'))
            time_diff = now - created_at
            
            # Check 60-minute policy
            if time_diff.total_seconds() <= 3600:  # 60 minutes = 3600 seconds
                return {
                    "cancelled": True,
                    "order_id": order_id,
                    "message": "Order successfully cancelled",
                    "refund_timeline": "3-5 business days"
                }
            else:
                return {
                    "cancelled": False,
                    "reason": "exceeds_60_minute_window",
                    "time_elapsed": f"{time_diff.total_seconds() / 3600:.1f} hours",
                    "alternatives": [
                        "Update shipping address (if not yet shipped)",
                        "Return for store credit after delivery",
                        "Contact support for special circumstances"
                    ]
                }
    
    return {
        "cancelled": False,
        "reason": "order_not_found"
    }

# Tool definitions for LangGraph
TOOLS = [
    {
        "name": "product_search",
        "description": "Search for products by query, price limit, and tags",
        "function": product_search
    },
    {
        "name": "size_recommender", 
        "description": "Get size recommendations based on user preferences",
        "function": size_recommender
    },
    {
        "name": "eta",
        "description": "Calculate estimated delivery time for a zip code",
        "function": eta
    },
    {
        "name": "order_lookup",
        "description": "Look up order details by order ID and email",
        "function": order_lookup
    },
    {
        "name": "order_cancel",
        "description": "Cancel an order within the 60-minute policy window",
        "function": order_cancel
    }
]