"""
Mock version of the commerce agent for testing without API keys.
"""
import json
from datetime import datetime, timezone
from typing import Dict, Any, List

from .tools import product_search, size_recommender, eta, order_lookup, order_cancel

class MockCommerceAgent:
    """Mock commerce agent that doesn't require OpenAI API."""
    
    def __init__(self):
        pass
    
    def run(self, user_input: str) -> Dict[str, Any]:
        """Run the agent with mocked LLM responses."""
        # Mock intent classification
        intent = self._mock_classify_intent(user_input)
        
        # Execute tools based on intent
        tools_called = []
        evidence = []
        
        if intent == "product_assist":
            tools_called, evidence = self._handle_product_assist(user_input)
        elif intent == "order_help":
            tools_called, evidence = self._handle_order_help(user_input)
        
        # Policy decisions
        policy_decision = self._make_policy_decision(intent, evidence, user_input)
        
        # Generate final message
        final_message = self._generate_response(intent, evidence, policy_decision, user_input)
        
        return {
            "intent": intent,
            "tools_called": tools_called,
            "evidence": evidence,
            "policy_decision": policy_decision,
            "final_message": final_message
        }
    
    def _mock_classify_intent(self, user_input: str) -> str:
        """Mock intent classification."""
        user_lower = user_input.lower()
        
        if any(word in user_lower for word in ["wedding", "dress", "midi", "search", "eta", "size"]):
            return "product_assist"
        elif any(word in user_lower for word in ["cancel", "order", "a1001", "a1002", "a1003"]):
            return "order_help"
        else:
            return "other"
    
    def _handle_product_assist(self, user_input: str) -> tuple:
        """Handle product assistance requests."""
        tools_called = []
        evidence = []
        
        # Extract price limit
        price_max = self._extract_price_limit(user_input)
        
        # Extract tags/categories
        tags = self._extract_tags(user_input)
        
        # Search products
        search_result = product_search(user_input, price_max, tags)
        tools_called.append("product_search")
        evidence.append({"source": "product_search", "data": search_result})
        
        # Get size recommendation if mentioned
        if any(word in user_input.lower() for word in ["size", "m/l", "between", "fit"]):
            size_result = size_recommender(user_input)
            tools_called.append("size_recommender")
            evidence.append({"source": "size_recommender", "data": size_result})
        
        # Get ETA if zip code mentioned
        zip_code = self._extract_zip_code(user_input)
        if zip_code:
            eta_result = eta(zip_code)
            tools_called.append("eta")
            evidence.append({"source": "eta", "data": eta_result})
        
        return tools_called, evidence
    
    def _handle_order_help(self, user_input: str) -> tuple:
        """Handle order-related requests."""
        tools_called = []
        evidence = []
        
        # Extract order ID and email
        order_id = self._extract_order_id(user_input)
        email = self._extract_email(user_input)
        
        if order_id and email:
            # Look up order
            lookup_result = order_lookup(order_id, email)
            tools_called.append("order_lookup")
            evidence.append({"source": "order_lookup", "data": lookup_result})
            
            # If cancellation requested and order found
            if "cancel" in user_input.lower() and lookup_result.get("found"):
                # Use simulated current time for testing
                if order_id == "A1003":
                    # Simulate A1003 as within 60 minutes
                    simulated_time = "2025-09-07T12:20:00Z"  # 25 minutes after A1003 creation
                else:
                    # Use default current time for other orders
                    simulated_time = None
                
                cancel_result = order_cancel(order_id, simulated_time)
                tools_called.append("order_cancel")
                evidence.append({"source": "order_cancel", "data": cancel_result})
        
        return tools_called, evidence
    
    def _make_policy_decision(self, intent: str, evidence: List[Dict], user_input: str) -> Dict:
        """Make policy decisions."""
        if intent == "order_help":
            # Check cancellation policy
            for item in evidence:
                if item["source"] == "order_cancel":
                    cancel_data = item["data"]
                    return {
                        "cancel_allowed": cancel_data.get("cancelled", False),
                        "reason": cancel_data.get("reason", "")
                    }
        elif intent == "other":
            # Handle guardrails (discount codes, etc.)
            if "discount" in user_input.lower() or "code" in user_input.lower():
                return {
                    "refuse": True,
                    "reason": "no_discount_codes",
                    "alternatives": ["newsletter signup", "first-order discount", "seasonal sales"]
                }
        
        return None
    
    def _generate_response(self, intent: str, evidence: List[Dict], policy_decision: Dict, user_input: str) -> str:
        """Generate contextual response."""
        if intent == "product_assist":
            return self._generate_product_response(evidence)
        elif intent == "order_help":
            return self._generate_order_response(evidence, policy_decision)
        else:
            return self._generate_other_response(user_input, policy_decision)
    
    def _generate_product_response(self, evidence: List[Dict]) -> str:
        """Generate product assistance response."""
        products = []
        size_rec = None
        eta_info = None
        
        for item in evidence:
            if item["source"] == "product_search":
                products = item["data"]["products"]
            elif item["source"] == "size_recommender":
                size_rec = item["data"]
            elif item["source"] == "eta":
                eta_info = item["data"]
        
        if not products:
            return "I couldn't find any products matching your criteria. Try adjusting your price range or preferences."
        
        response = "Here are my top recommendations:\n\n"
        
        for i, product in enumerate(products[:2], 1):
            response += f"{i}. {product['title']} - ${product['price']}\n"
            response += f"   Color: {product['color']}, Sizes: {', '.join(product['sizes'])}\n"
            if product['tags']:
                response += f"   Perfect for: {', '.join(product['tags'])}\n"
            response += "\n"
        
        if size_rec:
            response += f"Size Guidance: {size_rec['recommendation']}\n\n"
        
        if eta_info:
            response += f"Delivery: {eta_info['estimated_delivery']} to {eta_info['zip_code']}\n"
        
        return response.strip()
    
    def _generate_order_response(self, evidence: List[Dict], policy_decision: Dict) -> str:
        """Generate order management response."""
        order_found = False
        order_data = None
        cancel_data = None
        
        for item in evidence:
            if item["source"] == "order_lookup":
                order_found = item["data"]["found"]
                if order_found:
                    order_data = item["data"]["order"]
            elif item["source"] == "order_cancel":
                cancel_data = item["data"]
        
        if not order_found:
            return "I couldn't find that order. Please check your order ID and email address."
        
        if cancel_data:
            if cancel_data.get("cancelled"):
                return f"Your order {order_data['order_id']} has been successfully cancelled. You'll receive a full refund within {cancel_data['refund_timeline']}."
            else:
                response = f"I can't cancel order {order_data['order_id']} because it exceeds our 60-minute cancellation window"
                if "time_elapsed" in cancel_data:
                    response += f" (placed {cancel_data['time_elapsed']} ago)"
                response += ".\n\nHowever, I can help you with:\n"
                for alt in cancel_data.get("alternatives", []):
                    response += f"• {alt}\n"
                return response.strip()
        
        # Just lookup, show order details
        items_desc = ", ".join([f"{item['id']} (size {item['size']})" for item in order_data['items']])
        return f"Found your order {order_data['order_id']} placed on {order_data['created_at'][:10]}. Items: {items_desc}"
    
    def _generate_other_response(self, user_input: str, policy_decision: Dict) -> str:
        """Generate response for other/guardrail cases."""
        if policy_decision and policy_decision.get("refuse"):
            if policy_decision["reason"] == "no_discount_codes":
                return ("I don't have any discount codes to share, but here are some ways to save: "
                       "Sign up for our newsletter for exclusive offers, check out our first-order discount for new customers, "
                       "or browse our seasonal sales section!")
        
        return "I'm here to help with product searches and order management. How can I assist you today?"
    
    # Helper methods (same as main agent)
    def _extract_price_limit(self, text: str) -> int:
        """Extract price limit from text."""
        import re
        matches = re.findall(r'under \$?(\d+)|below \$?(\d+)|max \$?(\d+)', text.lower())
        if matches:
            for match in matches[0]:
                if match:
                    return int(match)
        return None
    
    def _extract_tags(self, text: str) -> List[str]:
        """Extract relevant tags from text."""
        tag_mapping = {
            "wedding": ["wedding", "guest", "formal"],
            "midi": ["midi"],
            "party": ["party", "night", "evening"],
            "daywear": ["day", "casual", "work"]
        }
        
        text_lower = text.lower()
        found_tags = []
        
        for tag, keywords in tag_mapping.items():
            if any(keyword in text_lower for keyword in keywords):
                found_tags.append(tag)
        
        return found_tags
    
    def _extract_zip_code(self, text: str) -> str:
        """Extract zip code from text."""
        import re
        match = re.search(r'\b(\d{5,6})\b', text)
        return match.group(1) if match else None
    
    def _extract_order_id(self, text: str) -> str:
        """Extract order ID from text."""
        import re
        match = re.search(r'\b(A\d+)\b', text)
        return match.group(1) if match else None
    
    def _extract_email(self, text: str) -> str:
        """Extract email from text."""
        import re
        match = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
        return match.group(0) if match else None