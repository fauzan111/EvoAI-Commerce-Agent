#!/usr/bin/env python3
"""
Unit tests for the 60-minute cancellation policy.
"""
import sys
from pathlib import Path
from datetime import datetime, timezone, timedelta

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from tools import order_cancel

def test_cancellation_within_60_minutes():
    """Test that orders can be cancelled within 60 minutes."""
    # Simulate current time as 30 minutes after order creation
    order_time = "2025-09-07T11:55:00Z"
    current_time = "2025-09-07T12:25:00Z"  # 30 minutes later
    
    result = order_cancel("A1003", current_time)
    
    assert result["cancelled"] == True
    assert "successfully cancelled" in result["message"]
    print("✓ Test passed: Cancellation within 60 minutes allowed")

def test_cancellation_after_60_minutes():
    """Test that orders cannot be cancelled after 60 minutes."""
    # Simulate current time as 90 minutes after order creation
    order_time = "2025-09-07T11:55:00Z"
    current_time = "2025-09-07T13:25:00Z"  # 90 minutes later
    
    result = order_cancel("A1003", current_time)
    
    assert result["cancelled"] == False
    assert result["reason"] == "exceeds_60_minute_window"
    assert "alternatives" in result
    print("✓ Test passed: Cancellation after 60 minutes blocked")

def test_cancellation_exactly_60_minutes():
    """Test edge case: exactly 60 minutes."""
    # Simulate current time as exactly 60 minutes after order creation
    order_time = "2025-09-07T11:55:00Z"
    current_time = "2025-09-07T12:55:00Z"  # exactly 60 minutes later
    
    result = order_cancel("A1003", current_time)
    
    assert result["cancelled"] == True  # Should still be allowed at exactly 60 minutes
    print("✓ Test passed: Cancellation at exactly 60 minutes allowed")

def test_nonexistent_order():
    """Test cancellation of non-existent order."""
    result = order_cancel("INVALID", "2025-09-07T12:00:00Z")
    
    assert result["cancelled"] == False
    assert result["reason"] == "order_not_found"
    print("✓ Test passed: Non-existent order handled correctly")

def main():
    """Run all policy tests."""
    print("Running 60-minute policy tests...")
    print("=" * 40)
    
    try:
        test_cancellation_within_60_minutes()
        test_cancellation_after_60_minutes()
        test_cancellation_exactly_60_minutes()
        test_nonexistent_order()
        
        print("\n" + "=" * 40)
        print("All policy tests passed! ✓")
        
    except AssertionError as e:
        print(f"Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Error running tests: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()