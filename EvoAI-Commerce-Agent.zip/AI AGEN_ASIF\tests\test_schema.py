#!/usr/bin/env python3
"""
JSON schema validation tests for agent traces.
"""
import sys
import json
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

def validate_trace_schema(trace: dict) -> bool:
    """Validate that trace follows the required schema."""
    required_keys = ["intent", "tools_called", "evidence", "policy_decision", "final_message"]
    
    # Check all required keys exist
    for key in required_keys:
        if key not in trace:
            raise ValueError(f"Missing required key: {key}")
    
    # Validate intent values
    valid_intents = ["product_assist", "order_help", "other"]
    if trace["intent"] not in valid_intents:
        raise ValueError(f"Invalid intent: {trace['intent']}")
    
    # Validate tools_called is a list
    if not isinstance(trace["tools_called"], list):
        raise ValueError("tools_called must be a list")
    
    # Validate evidence is a list of objects
    if not isinstance(trace["evidence"], list):
        raise ValueError("evidence must be a list")
    
    for item in trace["evidence"]:
        if not isinstance(item, dict):
            raise ValueError("evidence items must be objects")
        if "source" not in item or "data" not in item:
            raise ValueError("evidence items must have 'source' and 'data' keys")
    
    # Validate final_message is a string
    if not isinstance(trace["final_message"], str):
        raise ValueError("final_message must be a string")
    
    return True

def test_schema_validation():
    """Test the schema validation function."""
    # Valid trace
    valid_trace = {
        "intent": "product_assist",
        "tools_called": ["product_search"],
        "evidence": [{"source": "product_search", "data": {"products": []}}],
        "policy_decision": None,
        "final_message": "Test message"
    }
    
    try:
        validate_trace_schema(valid_trace)
        print("✓ Valid trace schema test passed")
    except Exception as e:
        print(f"✗ Valid trace schema test failed: {e}")
        return False
    
    # Invalid trace - missing key
    invalid_trace = {
        "intent": "product_assist",
        "tools_called": ["product_search"],
        # missing evidence, policy_decision, final_message
    }
    
    try:
        validate_trace_schema(invalid_trace)
        print("✗ Invalid trace should have failed validation")
        return False
    except ValueError:
        print("✓ Invalid trace correctly rejected")
    
    return True

def main():
    """Run schema validation tests."""
    print("Running JSON schema validation tests...")
    print("=" * 40)
    
    if test_schema_validation():
        print("\n" + "=" * 40)
        print("Schema validation tests passed! ✓")
    else:
        print("\n" + "=" * 40)
        print("Schema validation tests failed! ✗")
        sys.exit(1)

if __name__ == "__main__":
    main()