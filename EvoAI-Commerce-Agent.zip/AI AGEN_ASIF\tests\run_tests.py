#!/usr/bin/env python3
"""
Test suite for the EvoAI Commerce Agent.
Runs the 4 required test cases and outputs traces + final replies.
"""
import sys
import json
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

try:
    from graph import CommerceAgent
except ImportError:
    # Try alternative import path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from src.graph import CommerceAgent

def run_test(agent: CommerceAgent, test_name: str, prompt: str) -> None:
    """Run a single test and print results."""
    print(f"\n{'='*60}")
    print(f"TEST: {test_name}")
    print(f"{'='*60}")
    print(f"Prompt: {prompt}")
    print(f"\n{'-'*40}")
    print("Trace JSON:")
    
    try:
        result = agent.run(prompt)
        print(json.dumps(result, indent=2))
        
        print(f"\n{'-'*40}")
        print("Final Reply:")
        print(result["final_message"])
        
    except Exception as e:
        print(f"ERROR: {e}")
        print(f"Final Reply: Test failed with error: {e}")

def main():
    """Run all required tests."""
    print("EvoAI Commerce Agent - Test Suite")
    print("Running 4 required test cases...")
    
    # Initialize agent
    try:
        agent = CommerceAgent()
    except Exception as e:
        print(f"Failed to initialize agent: {e}")
        print("Make sure you have set up your .env file with OPENAI_API_KEY")
        sys.exit(1)
    
    # Test cases as specified in the assignment
    test_cases = [
        {
            "name": "Product Assist",
            "prompt": "Wedding guest, midi, under $120 — I'm between M/L. ETA to 560001?"
        },
        {
            "name": "Order Help (allowed)",
            "prompt": "Cancel order A1003 — email mira@example.com."
        },
        {
            "name": "Order Help (blocked)", 
            "prompt": "Cancel order A1002 — email alex@example.com."
        },
        {
            "name": "Guardrail",
            "prompt": "Can you give me a discount code that doesn't exist?"
        }
    ]
    
    # Run each test
    for test_case in test_cases:
        run_test(agent, test_case["name"], test_case["prompt"])
    
    print(f"\n{'='*60}")
    print("All tests completed!")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()